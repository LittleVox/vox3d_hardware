fx_version 'bodacious'
game 'gta5'

author 'Vox_3D x m-Scripts'
version '1.0.0'

client_script{
    'client.lua'
}